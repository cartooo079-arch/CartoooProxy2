document.addEventListener('DOMContentLoaded', ()=>{
  const addBtn = document.getElementById('addTab');
  const tabsArea = document.querySelector('.tabs-area');
  const urlBar = document.getElementById('urlBar');
  const goBtn = document.getElementById('goBtn');
  const iframe = document.getElementById('uv-frame');
  const backBtn = document.getElementById('backBtn');
  const forwardBtn = document.getElementById('forwardBtn');
  const reloadBtn = document.getElementById('reloadBtn');

  addBtn.addEventListener('click', ()=>{
    const t = document.createElement('div');
    t.className='tab';
    t.textContent='New Tab';
    tabsArea.insertBefore(t, addBtn);
    t.addEventListener('click', ()=>{ document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active')); t.classList.add('active'); });
    t.click();
  });

  goBtn.addEventListener('click', ()=>{
    let target = urlBar.value.trim();
    if(!target) return;
    if(!/^https?:\/\//i.test(target)) target = 'https://'+target;
    try {
      const win = iframe.contentWindow;
      if(win && typeof win.uvNavigate === 'function') {
        win.uvNavigate(target);
      } else {
        alert('Navigation requested. Replace uv.bundle.js with a real Ultraviolet bundle for in-proxy navigation.');
      }
    } catch(e){
      console.warn(e);
    }
  });

  backBtn.addEventListener('click', ()=>{ try { iframe.contentWindow.history.back(); } catch(e){} });
  forwardBtn.addEventListener('click', ()=>{ try { iframe.contentWindow.history.forward(); } catch(e){} });
  reloadBtn.addEventListener('click', ()=>{ try { iframe.contentWindow.location.reload(); } catch(e){} });
});
